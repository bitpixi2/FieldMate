import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import { LiveScreen } from "./components/live/LiveScreen";
import "./theme/amber-tokens.css";

createRoot(document.getElementById("root")!).render(
  <StrictMode>
    <LiveScreen />
  </StrictMode>,
);
