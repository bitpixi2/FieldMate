/**
 * @file MCP App entry. Renders the FieldMate consumer-capture flow (Top 3)
 * inside the MCP host, using `useApp()` to connect and honour safe-area insets.
 */
import type { McpUiHostContext } from "@modelcontextprotocol/ext-apps";
import { useApp } from "@modelcontextprotocol/ext-apps/react";
import { StrictMode, useEffect, useState } from "react";
import { createRoot } from "react-dom/client";
import { CaptureScreen } from "./components/capture/CaptureScreen";
import "./theme/amber-tokens.css";

function CaptureApp() {
  const [hostContext, setHostContext] = useState<McpUiHostContext | undefined>();

  const { app } = useApp({
    appInfo: { name: "FieldMate — Capture", version: "1.0.0" },
    capabilities: {},
    onAppCreated: (app) => {
      app.onhostcontextchanged = (params) =>
        setHostContext((prev) => ({ ...prev, ...params }));
      app.onerror = console.error;
    },
  });

  useEffect(() => {
    if (app) setHostContext(app.getHostContext());
  }, [app]);

  function handleRedeem(amount: number) {
    console.log("reward-redeemed", amount);
  }

  return (
    <div
      style={{
        paddingTop: hostContext?.safeAreaInsets?.top,
        paddingRight: hostContext?.safeAreaInsets?.right,
        paddingBottom: hostContext?.safeAreaInsets?.bottom,
        paddingLeft: hostContext?.safeAreaInsets?.left,
      }}
    >
      <CaptureScreen onRedeem={handleRedeem} />
    </div>
  );
}

createRoot(document.getElementById("root")!).render(
  <StrictMode>
    <CaptureApp />
  </StrictMode>,
);
