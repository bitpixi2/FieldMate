/** @file SVG icons for the LIVE selling-energy screen. */

interface IconProps {
  c?: string;
}

export const BatteryIcon = ({ c = "#fff" }: IconProps) => (
  <svg width="26" height="16" viewBox="0 0 26 16" fill="none">
    <rect x="1" y="1.5" width="20" height="13" rx="3" stroke={c} strokeWidth="2" />
    <rect x="3.5" y="4" width="14" height="8" rx="1.5" fill={c} />
    <rect x="22.5" y="5.5" width="2.5" height="5" rx="1" fill={c} />
  </svg>
);

export const DollarCircle = ({ c = "#13294b" }: IconProps) => (
  <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
    <circle cx="10" cy="10" r="8.5" stroke={c} strokeWidth="1.8" />
    <text x="10" y="14.3" textAnchor="middle" fontSize="11" fontWeight="800" fill={c} fontFamily="Arial">$</text>
  </svg>
);

export const LeafIcon = ({ c = "#13294b" }: IconProps) => (
  <svg width="20" height="22" viewBox="0 0 20 22" fill="none">
    <path d="M10 21V8" stroke={c} strokeWidth="1.8" strokeLinecap="round" />
    <path d="M10 12c0-4 3-7 8-7 0 4-3 7-8 7Z" stroke={c} strokeWidth="1.8" strokeLinejoin="round" />
    <path d="M10 9C10 5 7 2 2 2c0 4 3 7 8 7Z" stroke={c} strokeWidth="1.8" strokeLinejoin="round" />
  </svg>
);

export const ChargeBattery = ({ c = "#5fd07e" }: IconProps) => (
  <svg width="30" height="20" viewBox="0 0 30 20" fill="none">
    <rect x="1" y="3" width="22" height="14" rx="3" stroke={c} strokeWidth="2" />
    <rect x="25" y="7" width="2.6" height="6" rx="1" fill={c} />
    <path d="M13 6l-4 5h3l-1.5 4 5-6h-3.2L13 6Z" fill={c} />
  </svg>
);

export const SolarIcon = ({ c = "#f3c220" }: IconProps) => (
  <svg width="28" height="24" viewBox="0 0 28 24" fill="none">
    <circle cx="14" cy="5" r="3" stroke={c} strokeWidth="1.8" />
    <path d="M14 0v1.5M14 8.5V10M19 5h-1.5M10.5 5H9M17.5 1.5l-1 1M11.5 8.5l-1 1M10.5 1.5l1 1M16.5 8.5l1 1" stroke={c} strokeWidth="1.6" strokeLinecap="round" />
    <path d="M6 13h16l3 9H3l3-9Z" stroke={c} strokeWidth="1.8" strokeLinejoin="round" />
    <path d="M11 13l-1 9M17 13l1 9M4.5 17.5h19" stroke={c} strokeWidth="1.5" />
  </svg>
);

export const FactoryIcon = ({ c = "#ec5fd0" }: IconProps) => (
  <svg width="28" height="24" viewBox="0 0 28 24" fill="none">
    <path d="M3 22V11l7 4V11l7 4V4h6v18H3Z" stroke={c} strokeWidth="1.8" strokeLinejoin="round" />
    <path d="M3 22h22" stroke={c} strokeWidth="1.8" strokeLinecap="round" />
  </svg>
);

export const HomeIcon = ({ c = "#3fb9e6" }: IconProps) => (
  <svg width="28" height="24" viewBox="0 0 28 24" fill="none">
    <path d="M4 11l10-7 10 7" stroke={c} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
    <path d="M6.5 9.5V21h15V9.5" stroke={c} strokeWidth="1.8" strokeLinejoin="round" />
    <path d="M11.5 21v-6h5v6" stroke={c} strokeWidth="1.6" />
  </svg>
);

export const ShuffleCircle = ({ c = "#13294b" }: IconProps) => (
  <svg width="30" height="30" viewBox="0 0 30 30" fill="none">
    <circle cx="15" cy="15" r="13" stroke={c} strokeWidth="2" />
    <path d="M9 10l12 10M21 10L9 20" stroke={c} strokeWidth="2" strokeLinecap="round" />
    <path d="M9 10h3M9 10v3M21 20h-3M21 20v-3" stroke={c} strokeWidth="2" strokeLinecap="round" />
  </svg>
);

export const Bolt = ({ c = "#13294b" }: IconProps) => (
  <svg width="14" height="20" viewBox="0 0 14 20" fill="none">
    <path d="M8 1L1 11h4l-1 8 9-11H8l1-7Z" fill={c} />
  </svg>
);

export const Chevron = ({ c = "#fff" }: IconProps) => (
  <svg width="22" height="22" viewBox="0 0 22 22" fill="none">
    <path d="M5 8l6 6 6-6" stroke={c} strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" />
  </svg>
);
