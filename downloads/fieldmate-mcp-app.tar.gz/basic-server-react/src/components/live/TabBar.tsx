import type { Tab } from "./data";
import { Bolt } from "./icons";
import s from "./live.module.css";

interface TabBarProps {
  active: Tab;
  onChange: (tab: Tab) => void;
}

export function TabBar({ active, onChange }: TabBarProps) {
  return (
    <div className={s.tabs}>
      <button
        className={`${s.tab} ${active === "History" ? s.tabActive : ""}`}
        onClick={() => onChange("History")}
      >
        History
      </button>
      <button
        className={`${s.tab} ${s.tabLive} ${active === "LIVE" ? s.tabLiveActive : ""}`}
        onClick={() => onChange("LIVE")}
      >
        <Bolt /> LIVE
      </button>
      <button
        className={`${s.tab} ${active === "Plan" ? s.tabActive : ""}`}
        onClick={() => onChange("Plan")}
      >
        Plan
      </button>
    </div>
  );
}
