import type { LiveData } from "./data";
import { ShuffleCircle } from "./icons";
import s from "./live.module.css";

export function EarningsCard({ data }: { data: LiveData }) {
  const [whole, cents] = data.totalEarnings.toFixed(2).split(".");
  return (
    <div className={s.cardWrap}>
      <div className={s.card}>
        <div className={s.cardTop}>
          <div className={s.cardTitleWrap}>
            <span className={s.cardTitle}>TOTAL EARNINGS</span>
            <ShuffleCircle />
          </div>
          <div className={s.col}>
            <div className={s.colLabel}>IMPORT COSTS</div>
            <div className={s.colAmount}>${data.importCosts.toFixed(2)}</div>
          </div>
        </div>

        <div className={s.bigRow}>
          <div className={s.bigNum}>
            <span className={s.bigDollar}>$</span>
            <span className={s.bigValue}>
              {whole}.{cents}
            </span>
          </div>
          <div className={s.exportCol}>
            <div className={s.colLabel}>
              EXPORT
              <br />
              EARNINGS
            </div>
            <div className={s.colAmount}>${data.exportEarnings.toFixed(2)}</div>
          </div>
        </div>
      </div>
    </div>
  );
}
