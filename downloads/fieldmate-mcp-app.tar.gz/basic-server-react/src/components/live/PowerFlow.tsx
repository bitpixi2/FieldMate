import type { LiveData } from "./data";
import { ChargeBattery, Chevron, FactoryIcon, HomeIcon, SolarIcon } from "./icons";
import s from "./live.module.css";

export function PowerFlow({ data }: { data: LiveData }) {
  return (
    <div className={s.mid}>
      <div className={`${s.kwRow} ${s.kwRowTop}`}>
        <span className={`${s.kw} ${s.kwGreen}`}>
          <ChargeBattery /> {data.charge.toFixed(1)} <span className={s.kwUnit}>kW</span>
        </span>
        <span className={`${s.kw} ${s.kwYellow}`}>
          <SolarIcon /> {data.solar.toFixed(1)} <span className={s.kwUnit}>kW</span>
        </span>
      </div>

      <div className={s.bar}>
        <div style={{ width: `${data.bar1[0]}%`, background: "var(--green)" }} />
        <div style={{ width: `${data.bar1[1]}%`, background: "var(--yellow)" }} />
      </div>

      <div className={s.flow}>
        <div className={s.flowTitle}>POWER FLOW</div>
        <div className={s.flowPanel} />
        <div className={s.flowFrom}>FROM</div>
        <div className={s.flowTo}>TO</div>
        <div className={s.flowChevron}>
          <Chevron />
        </div>
      </div>

      <div className={s.bar}>
        <div style={{ width: `${data.bar2[0]}%`, background: "var(--pink)" }} />
        <div style={{ width: `${data.bar2[1]}%`, background: "var(--cyan)" }} />
      </div>

      <div className={`${s.kwRow} ${s.kwRowBottom}`}>
        <span className={`${s.kw} ${s.kwPink}`}>
          <FactoryIcon /> {data.factory.toFixed(1)} <span className={s.kwUnit}>kW</span>
        </span>
        <span className={`${s.kw} ${s.kwCyan}`}>
          <HomeIcon /> {data.home.toFixed(1)} <span className={s.kwUnit}>kW</span>
        </span>
      </div>
    </div>
  );
}
