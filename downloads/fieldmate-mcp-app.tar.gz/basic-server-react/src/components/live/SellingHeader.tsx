import s from "./live.module.css";

export function SellingHeader() {
  return (
    <>
      <h1 className={s.heading}>YOU'RE SELLING ENERGY</h1>
      <p className={s.subtitle}>
        Your <b>green energy</b> is in demand and valuable to a <b>dirty grid</b>.
        It's a great time to sell!
      </p>
    </>
  );
}
