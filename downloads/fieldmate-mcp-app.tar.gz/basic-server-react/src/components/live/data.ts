/** @file Data model driving the LIVE selling-energy screen. */

export type Tab = "History" | "LIVE" | "Plan";

export interface LiveData {
  battery: number;
  sell: number;
  green: number;
  charge: number;
  solar: number;
  factory: number;
  home: number;
  /** [green%, yellow%] of the production bar. */
  bar1: [number, number];
  /** [pink%, cyan%] of the flow bar. */
  bar2: [number, number];
  totalEarnings: number;
  importCosts: number;
  exportEarnings: number;
}

export const DEFAULT_LIVE: LiveData = {
  battery: 70,
  sell: 18.38,
  green: 50,
  charge: 5.0,
  solar: 4.6,
  factory: 9.3,
  home: 0.3,
  bar1: [46, 30],
  bar2: [70, 7],
  totalEarnings: 164.71,
  importCosts: 0.02,
  exportEarnings: 164.73,
};
