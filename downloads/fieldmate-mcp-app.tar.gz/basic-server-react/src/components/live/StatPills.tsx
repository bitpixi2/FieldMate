import type { LiveData } from "./data";
import { BatteryIcon, DollarCircle, LeafIcon } from "./icons";
import s from "./live.module.css";

export function StatPills({ data }: { data: LiveData }) {
  return (
    <div className={s.pills}>
      <button className={`${s.pill} ${s.pillBattery}`}>
        <BatteryIcon /> {data.battery}%
      </button>

      <button className={`${s.pill} ${s.pillSell}`}>
        <span className={s.sellStack}>
          <DollarCircle />
          <span className={s.sellLabel}>SELL</span>
        </span>
        <span className={s.sellAmount}>${data.sell.toFixed(2)}</span>
      </button>

      <button
        className={`${s.pill} ${s.pillGreen}`}
        style={{
          background: `linear-gradient(90deg, var(--green) ${data.green}%, var(--gray) ${data.green}%)`,
        }}
      >
        <span className={s.pillGreenInner}>
          <LeafIcon /> {data.green}%
        </span>
      </button>
    </div>
  );
}
