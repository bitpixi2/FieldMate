import { useState } from "react";
import { DEFAULT_LIVE, type LiveData, type Tab } from "./data";
import { EarningsCard } from "./EarningsCard";
import { PowerFlow } from "./PowerFlow";
import { SellingHeader } from "./SellingHeader";
import { StatPills } from "./StatPills";
import { TabBar } from "./TabBar";
import s from "./live.module.css";

function formatClock(iso?: string): string | null {
  if (!iso) return null;
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return iso;
  return d.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", hour12: false });
}

interface LiveScreenProps {
  data?: LiveData;
  /** ISO 8601 server time; when present, renders a live clock chip. */
  serverTime?: string;
}

export function LiveScreen({ data = DEFAULT_LIVE, serverTime }: LiveScreenProps) {
  const [tab, setTab] = useState<Tab>("LIVE");
  const clock = formatClock(serverTime);

  return (
    <div className={s.screen}>
      <div className={s.gradient}>
        {clock && (
          <div className={s.statusRow}>
            <span className={s.clock}>{clock}</span>
          </div>
        )}
        <TabBar active={tab} onChange={setTab} />
        <SellingHeader />
        <StatPills data={data} />
      </div>

      <PowerFlow data={data} />
      <EarningsCard data={data} />

      <div className={s.peek}>
        <div className={`${s.peekCard} ${s.peekYellow}`} />
        <div className={`${s.peekCard} ${s.peekGreen}`} />
      </div>
    </div>
  );
}
