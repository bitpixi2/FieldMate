import s from "./capture.module.css";

interface ErrorBannerProps {
  title: string;
  hint?: string;
}

export function ErrorBanner({ title, hint }: ErrorBannerProps) {
  return (
    <div className={s.errorBanner} role="alert">
      <span className={s.errorTitle}>{title}</span>
      {hint && <span className={s.errorHint}>{hint}</span>}
    </div>
  );
}
