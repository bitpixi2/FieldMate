/** @file Page model + wizard state for the multi-page rewards capture flow. */

export type PageKey =
  | "demographics"
  | "intro"
  | "meter"
  | "roof"
  | "pole"
  | "calculating"
  | "reward";

/** Forward order of the wizard pages. */
export const PAGE_ORDER: PageKey[] = [
  "demographics",
  "intro",
  "meter",
  "roof",
  "pole",
  "calculating",
  "reward",
];

export interface Demographics {
  name: string;
  phone: string;
  address: string;
  email: string;
}

export const EMPTY_DEMOGRAPHICS: Demographics = {
  name: "",
  phone: "",
  address: "",
  email: "",
};

export const ROOF_SIDES = ["Front", "Right", "Back", "Left"] as const;
export type RoofSide = (typeof ROOF_SIDES)[number];

export const POLE_ANGLES = ["Angle 1", "Angle 2"] as const;

/** Simulated reward landed by the wheel. */
export const REWARD_AMOUNT = 82;
export const REWARD_CURRENCY = "AUD";

/** Section metadata for the intro + progress chrome. */
export const SECTIONS = [
  { key: "meter", label: "Power meter" },
  { key: "roof", label: "Roof" },
  { key: "pole", label: "Power pole" },
] as const;

export interface WizardState {
  demographics: Demographics;
  meterDone: boolean;
  roofSidesDone: boolean[];
  poleAnglesDone: boolean[];
}

export const INITIAL_STATE: WizardState = {
  demographics: EMPTY_DEMOGRAPHICS,
  meterDone: false,
  roofSidesDone: [false, false, false, false],
  poleAnglesDone: [false, false],
};
