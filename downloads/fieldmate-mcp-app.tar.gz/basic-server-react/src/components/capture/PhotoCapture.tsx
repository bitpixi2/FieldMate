import { useRef } from "react";
import { CameraIcon, UploadIcon } from "./icons";
import s from "./capture.module.css";

interface PhotoCaptureProps {
  /** Data URL of the captured photo, if any. */
  photo?: string;
  onSelect: (dataUrl: string) => void;
  onClear: () => void;
}

export function PhotoCapture({ photo, onSelect, onClear }: PhotoCaptureProps) {
  const cameraRef = useRef<HTMLInputElement>(null);
  const uploadRef = useRef<HTMLInputElement>(null);

  function handleFile(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => onSelect(reader.result as string);
    reader.readAsDataURL(file);
    e.target.value = ""; // allow re-selecting the same file
  }

  return (
    <div>
      <div className={s.photo}>
        {photo ? (
          <>
            <img className={s.photoImg} src={photo} alt="Capture preview" />
            <button className={s.photoClear} onClick={onClear} aria-label="Remove photo">
              &times;
            </button>
          </>
        ) : (
          <span className={s.photoHint}>No photo yet</span>
        )}
      </div>

      <div className={s.captureBtns}>
        <button className={`${s.btn} ${s.btnCamera}`} onClick={() => cameraRef.current?.click()}>
          <CameraIcon /> Camera
        </button>
        <button className={`${s.btn} ${s.btnUpload}`} onClick={() => uploadRef.current?.click()}>
          <UploadIcon /> Upload
        </button>
      </div>

      <input ref={cameraRef} type="file" accept="image/*" capture="environment" hidden onChange={handleFile} />
      <input ref={uploadRef} type="file" accept="image/*" hidden onChange={handleFile} />
    </div>
  );
}
