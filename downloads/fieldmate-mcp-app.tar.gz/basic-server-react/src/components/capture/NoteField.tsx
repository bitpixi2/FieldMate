import s from "./capture.module.css";

interface NoteFieldProps {
  value: string;
  placeholder: string;
  onChange: (value: string) => void;
}

export function NoteField({ value, placeholder, onChange }: NoteFieldProps) {
  return (
    <div>
      <div className={s.noteLabel}>Note</div>
      <textarea
        className={s.note}
        value={value}
        placeholder={placeholder}
        rows={3}
        onChange={(e) => onChange(e.target.value)}
      />
    </div>
  );
}
