import { useState } from "react";
import { PhotoCapture } from "../PhotoCapture";
import { PoleExample } from "../ExampleArt";
import { POLE_ANGLES } from "../flow";
import s from "../capture.module.css";

export function PoleSection({ onNext }: { onNext: () => void }) {
  const [angle, setAngle] = useState(0);
  const [photo, setPhoto] = useState<string>();

  function usePhoto() {
    if (angle < POLE_ANGLES.length - 1) {
      setAngle((n) => n + 1);
      setPhoto(undefined);
    } else {
      onNext();
    }
  }

  return (
    <div className={s.page}>
      <span className={s.sectionTag}>
        Section 3 of 3 · Power pole · {POLE_ANGLES[angle]} ({angle + 1}/2)
      </span>
      <h1 className={s.pageTitle}>PHOTO YOUR POWER POLE</h1>
      <p className={s.pageIntent}>
        Success on the roof! Now take a photo of your power pole from two angles —
        stay at a safe distance from the ground.
      </p>

      <div className={s.exampleRow}>
        <PoleExample />
        <span className={s.exampleCaption}>Capture {POLE_ANGLES[angle]} of 2</span>
      </div>

      <PhotoCapture photo={photo} onSelect={setPhoto} onClear={() => setPhoto(undefined)} />

      <button className={s.primaryBtn} onClick={usePhoto} disabled={!photo}>
        {angle < POLE_ANGLES.length - 1 ? "Next angle" : "Calculate my rewards"}
      </button>
    </div>
  );
}
