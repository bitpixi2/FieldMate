import { SECTIONS } from "../flow";
import s from "../capture.module.css";

export function IntroPage({ onNext }: { onNext: () => void }) {
  return (
    <div className={s.page}>
      <h1 className={s.pageTitle}>HERE'S THE PLAN</h1>
      <p className={s.pageIntent}>
        This will take roughly <b>10 minutes per section</b>, and there are{" "}
        <b>3 sections</b> to complete. At the end, we calculate how much your energy
        credits are worth — and you redeem them right away.
      </p>

      <ol className={s.sectionList}>
        {SECTIONS.map((sec, i) => (
          <li key={sec.key} className={s.sectionItem}>
            <span className={s.sectionNum}>{i + 1}</span>
            <span className={s.sectionName}>{sec.label}</span>
            <span className={s.sectionTime}>~10 min</span>
          </li>
        ))}
      </ol>

      <button className={s.primaryBtn} onClick={onNext}>
        Start section 1
      </button>
    </div>
  );
}
