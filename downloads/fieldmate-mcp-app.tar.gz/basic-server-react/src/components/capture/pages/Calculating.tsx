import { useEffect } from "react";
import s from "../capture.module.css";

export function CalculatingPage({ onNext }: { onNext: () => void }) {
  useEffect(() => {
    const id = setTimeout(onNext, 2600);
    return () => clearTimeout(id);
  }, [onNext]);

  return (
    <div className={`${s.page} ${s.pageCenter}`}>
      <div className={s.spinner} aria-hidden />
      <h1 className={s.pageTitle}>CALCULATING YOUR REWARDS…</h1>
      <p className={s.pageIntent}>
        Tallying the energy credits from your meter, roof and pole captures.
      </p>
    </div>
  );
}
