import type { Demographics } from "../flow";
import s from "../capture.module.css";

interface DemographicsPageProps {
  value: Demographics;
  onChange: (patch: Partial<Demographics>) => void;
  onNext: () => void;
}

/**
 * Demographic fields. autocomplete attributes only — the browser may prefill
 * from its own saved chain, but nothing is fetched or stored by the app.
 */
export function DemographicsPage({ value, onChange, onNext }: DemographicsPageProps) {
  return (
    <div className={s.page}>
      <h1 className={s.pageTitle}>YOUR DETAILS</h1>
      <p className={s.pageIntent}>
        We only use these to send your energy-credit reward. Your browser may fill
        them in for you.
      </p>

      <form
        className={s.form}
        autoComplete="on"
        onSubmit={(e) => {
          e.preventDefault();
          onNext();
        }}
      >
        <label className={s.field}>
          <span className={s.fieldLabel}>NAME</span>
          <input
            className={s.input}
            type="text"
            name="name"
            autoComplete="name"
            placeholder="Full name"
            value={value.name}
            onChange={(e) => onChange({ name: e.target.value })}
          />
        </label>

        <label className={s.field}>
          <span className={s.fieldLabel}>PHONE</span>
          <input
            className={s.input}
            type="tel"
            name="phone"
            autoComplete="tel"
            placeholder="Mobile number"
            value={value.phone}
            onChange={(e) => onChange({ phone: e.target.value })}
          />
        </label>

        <label className={s.field}>
          <span className={s.fieldLabel}>ADDRESS</span>
          <input
            className={s.input}
            type="text"
            name="address"
            autoComplete="street-address"
            placeholder="Home address"
            value={value.address}
            onChange={(e) => onChange({ address: e.target.value })}
          />
        </label>

        <label className={s.field}>
          <span className={s.fieldLabel}>EMAIL</span>
          <input
            className={s.input}
            type="email"
            name="email"
            autoComplete="email"
            placeholder="Email address"
            value={value.email}
            onChange={(e) => onChange({ email: e.target.value })}
          />
        </label>

        <button className={s.primaryBtn} type="submit">
          Continue
        </button>
      </form>
    </div>
  );
}
