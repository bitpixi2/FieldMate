import { useState } from "react";
import { PhotoCapture } from "../PhotoCapture";
import { MeterExample } from "../ExampleArt";
import s from "../capture.module.css";

export function MeterSection({ onNext }: { onNext: () => void }) {
  const [clip, setClip] = useState<string>();

  return (
    <div className={s.page}>
      <span className={s.sectionTag}>Section 1 of 3 · Power meter</span>
      <h1 className={s.pageTitle}>WALK TO YOUR METER</h1>
      <p className={s.pageIntent}>
        First, stand at the front of your house and take a video walking to your power
        meter — then hold the camera still in front of the power meter.
      </p>

      <div className={s.exampleRow}>
        <MeterExample />
        <span className={s.exampleCaption}>It might look like this</span>
      </div>

      <PhotoCapture photo={clip} onSelect={setClip} onClear={() => setClip(undefined)} />

      {clip && <p className={s.successLine}>Great! Thanks!</p>}

      <button className={s.primaryBtn} onClick={onNext} disabled={!clip}>
        Next step
      </button>
    </div>
  );
}
