import { useEffect, useState } from "react";
import { REWARD_AMOUNT, REWARD_CURRENCY } from "../flow";
import s from "../capture.module.css";

const WHEEL_VALUES = [12, 34, 50, REWARD_AMOUNT, 19, 65, 28, 41];

interface RewardPageProps {
  /** Redeem CTA — wired to a host tool by the parent if available. */
  onRedeem?: () => void;
}

export function RewardPage({ onRedeem }: RewardPageProps) {
  const [spinning, setSpinning] = useState(true);
  const [display, setDisplay] = useState(WHEEL_VALUES[0]);

  // Cycle values quickly, then settle on the reward amount.
  useEffect(() => {
    let i = 0;
    let delay = 70;
    let timer: ReturnType<typeof setTimeout>;
    function tick() {
      i += 1;
      setDisplay(WHEEL_VALUES[i % WHEEL_VALUES.length]);
      delay *= 1.14;
      if (delay < 420) {
        timer = setTimeout(tick, delay);
      } else {
        setDisplay(REWARD_AMOUNT);
        setSpinning(false);
      }
    }
    timer = setTimeout(tick, delay);
    return () => clearTimeout(timer);
  }, []);

  return (
    <div className={`${s.page} ${s.pageCenter}`}>
      <span className={s.sectionTag}>All sections complete</span>
      <h1 className={s.pageTitle}>{spinning ? "SPINNING…" : "YOU WON!"}</h1>

      <div className={`${s.wheel} ${spinning ? s.wheelSpin : s.wheelLanded}`}>
        <span className={s.wheelCurrency}>$</span>
        <span className={s.wheelvalue}>{display}</span>
        <span className={s.wheelUnit}>{REWARD_CURRENCY}</span>
      </div>

      {!spinning && (
        <>
          <p className={s.pageIntent}>
            Worth <b>${REWARD_AMOUNT} {REWARD_CURRENCY}</b> in energy credits — added to
            your balance.
          </p>
          <button className={`${s.primaryBtn} ${s.redeemBtn}`} onClick={onRedeem}>
            Click here to redeem
          </button>
        </>
      )}
    </div>
  );
}
