import { useState } from "react";
import { PhotoCapture } from "../PhotoCapture";
import { RoofOutline } from "../RoofOutline";
import { RoofOutlineExample } from "../ExampleArt";
import { ErrorBanner } from "../ErrorBanner";
import { ROOF_SIDES } from "../flow";
import s from "../capture.module.css";

type Phase = "photo" | "outline";

export function RoofSection({ onNext }: { onNext: () => void }) {
  const [side, setSide] = useState(0);
  const [phase, setPhase] = useState<Phase>("photo");
  const [photo, setPhoto] = useState<string>();
  const [points, setPoints] = useState(0);
  // Demo error states are shown once, on the first side only.
  const [blurShown, setBlurShown] = useState(false);
  const [outlineErrShown, setOutlineErrShown] = useState(false);
  const [error, setError] = useState<{ title: string; hint: string; example?: boolean } | null>(null);

  const isDemoSide = side === 0;

  function usePhoto() {
    if (isDemoSide && !blurShown) {
      setBlurShown(true);
      setError({
        title: "Your picture was too blurry!",
        hint: "Take the photo again holding it still.",
      });
      setPhoto(undefined);
      return;
    }
    setError(null);
    setPhase("outline");
  }

  function finishOutline() {
    if (isDemoSide && !outlineErrShown) {
      setOutlineErrShown(true);
      setError({
        title: "You didn't complete the outline!",
        hint: "Try to draw a complete shape around the edges of the roof with your finger, like this.",
        example: true,
      });
      return;
    }
    setError(null);
    // advance to next side, or finish the section
    if (side < ROOF_SIDES.length - 1) {
      setSide((n) => n + 1);
      setPhase("photo");
      setPhoto(undefined);
      setPoints(0);
    } else {
      onNext();
    }
  }

  return (
    <div className={s.page}>
      <span className={s.sectionTag}>
        Section 2 of 3 · Roof · {ROOF_SIDES[side]} ({side + 1}/4)
      </span>

      {phase === "photo" ? (
        <>
          <h1 className={s.pageTitle}>PHOTO OF YOUR ROOF</h1>
          <p className={s.pageIntent}>
            Stand in front of your house again and take a picture from the ground of the
            roof. <b>Do not climb up onto your roof!</b>
          </p>

          {error && <ErrorBanner title={error.title} hint={error.hint} />}

          <PhotoCapture photo={photo} onSelect={setPhoto} onClear={() => setPhoto(undefined)} />

          <button className={s.primaryBtn} onClick={usePhoto} disabled={!photo}>
            Use this photo
          </button>
        </>
      ) : (
        <>
          <h1 className={s.pageTitle}>TRACE THE ROOF EDGE</h1>
          <p className={s.pageIntent}>
            Then draw a shape around your roof edge with your finger, like this.
          </p>

          {error?.example && (
            <div className={s.exampleRow}>
              <RoofOutlineExample />
              <span className={s.exampleCaption}>Draw a closed shape like this</span>
            </div>
          )}

          {error && <ErrorBanner title={error.title} hint={error.hint} />}

          <RoofOutline onChange={setPoints} />

          <button className={s.primaryBtn} onClick={finishOutline} disabled={points === 0}>
            {side < ROOF_SIDES.length - 1 ? "Next side" : "Finish roof"}
          </button>

          {side === 0 && !error && (
            <p className={s.helperLine}>Now do the same on the 3 other sides of your roof.</p>
          )}
        </>
      )}
    </div>
  );
}
