import { AmberMark, CoinIcon } from "./icons";
import s from "./capture.module.css";

interface AmberNavProps {
  /** Reward balance earned by the user, in dollars. */
  balance?: number;
}

/** Amber-branded top chrome: logo + glowing reward balance. */
export function AmberNav({ balance = 12.5 }: AmberNavProps) {
  return (
    <nav className={s.amberNav}>
      <span className={s.amberBrand}>
        <AmberMark />
        <span className={s.amberWord}>amber</span>
      </span>
      <span className={s.balance}>
        <CoinIcon />
        <span className={s.balanceCol}>
          <span className={s.balanceLabel}>BALANCE</span>
          <span className={s.balanceAmount}>${balance.toFixed(2)}</span>
        </span>
      </span>
    </nav>
  );
}
