/** @file SVG icons for the FieldMate capture flow. */

interface IconProps {
  c?: string;
}

export const CameraIcon = ({ c = "#0e2038" }: IconProps) => (
  <svg width="20" height="18" viewBox="0 0 20 18" fill="none">
    <path d="M2 5h3l1.5-2.5h7L15 5h3v11H2V5Z" stroke={c} strokeWidth="1.8" strokeLinejoin="round" />
    <circle cx="10" cy="10" r="3.3" stroke={c} strokeWidth="1.8" />
  </svg>
);

export const UploadIcon = ({ c = "#fff" }: IconProps) => (
  <svg width="18" height="18" viewBox="0 0 18 18" fill="none">
    <path d="M9 12V3M5.5 6.5 9 3l3.5 3.5" stroke={c} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
    <path d="M3 12v3h12v-3" stroke={c} strokeWidth="1.8" strokeLinecap="round" />
  </svg>
);

export const CheckIcon = ({ c = "#5fd07e" }: IconProps) => (
  <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
    <path d="M2.5 7.5 6 11l5.5-7.5" stroke={c} strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" />
  </svg>
);

export const CoinIcon = ({ c = "#00ffa8" }: IconProps) => (
  <svg width="18" height="18" viewBox="0 0 18 18" fill="none">
    <circle cx="9" cy="9" r="7.5" stroke={c} strokeWidth="1.8" />
    <circle cx="9" cy="9" r="4.4" stroke={c} strokeWidth="1.3" opacity="0.6" />
    <path d="M9 5.4v7.2M7.2 7h2.4a1.3 1.3 0 0 1 0 2.6H7.4h1.9a1.3 1.3 0 0 1 0 2.6H7.2" stroke={c} strokeWidth="1.3" strokeLinecap="round" strokeLinejoin="round" />
  </svg>
);

export const AmberMark = ({ c = "#00ffa8" }: IconProps) => (
  <svg width="28" height="28" viewBox="0 0 28 28" fill="none">
    <rect x="1" y="1" width="26" height="26" rx="9" fill={c} />
    <circle cx="14" cy="14" r="7" fill="none" stroke="#0a1a43" strokeWidth="2.4" />
    <circle cx="14" cy="14" r="2.4" fill="#0a1a43" />
  </svg>
);

export const ArrowRight = ({ c = "#0a1a43" }: IconProps) => (
  <svg width="18" height="16" viewBox="0 0 18 16" fill="none">
    <path d="M2 8h13M10 3l5 5-5 5" stroke={c} strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" />
  </svg>
);
