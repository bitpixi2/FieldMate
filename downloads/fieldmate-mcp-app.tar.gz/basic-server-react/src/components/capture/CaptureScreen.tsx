import { useState } from "react";
import { AmberNav } from "./AmberNav";
import {
  INITIAL_STATE,
  PAGE_ORDER,
  REWARD_AMOUNT,
  type Demographics,
  type PageKey,
  type WizardState,
} from "./flow";
import { DemographicsPage } from "./pages/Demographics";
import { IntroPage } from "./pages/Intro";
import { MeterSection } from "./pages/MeterSection";
import { RoofSection } from "./pages/RoofSection";
import { PoleSection } from "./pages/PoleSection";
import { CalculatingPage } from "./pages/Calculating";
import { RewardPage } from "./pages/Reward";
import s from "./capture.module.css";

interface CaptureScreenProps {
  /** Reward balance shown in the nav (grows after redeem). */
  balance?: number;
  /** Fired when the user redeems their reward. */
  onRedeem?: (amount: number) => void;
}

export function CaptureScreen({ balance = 12.5, onRedeem }: CaptureScreenProps) {
  const [page, setPage] = useState<PageKey>("demographics");
  const [state, setState] = useState<WizardState>(INITIAL_STATE);
  const [navBalance, setNavBalance] = useState(balance);

  function go(to: PageKey) {
    setPage(to);
  }
  function advance() {
    const i = PAGE_ORDER.indexOf(page);
    if (i < PAGE_ORDER.length - 1) go(PAGE_ORDER[i + 1]);
  }
  function patchDemographics(patch: Partial<Demographics>) {
    setState((p) => ({ ...p, demographics: { ...p.demographics, ...patch } }));
  }
  function redeem() {
    setNavBalance((b) => b + REWARD_AMOUNT);
    onRedeem?.(REWARD_AMOUNT);
  }

  return (
    <div className={s.screen}>
      <AmberNav balance={navBalance} />

      {page === "demographics" && (
        <DemographicsPage
          value={state.demographics}
          onChange={patchDemographics}
          onNext={advance}
        />
      )}
      {page === "intro" && <IntroPage onNext={advance} />}
      {page === "meter" && <MeterSection onNext={advance} />}
      {page === "roof" && <RoofSection onNext={advance} />}
      {page === "pole" && <PoleSection onNext={advance} />}
      {page === "calculating" && <CalculatingPage onNext={advance} />}
      {page === "reward" && <RewardPage onRedeem={redeem} />}
    </div>
  );
}
