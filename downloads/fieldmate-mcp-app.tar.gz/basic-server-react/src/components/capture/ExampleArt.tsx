/** @file Simple original SVG illustrations used as on-screen examples. */
import s from "./capture.module.css";

/** A stylised power meter on a wall — the "good example" for section 1. */
export function MeterExample() {
  return (
    <svg className={s.art} viewBox="0 0 120 120" fill="none" aria-label="Power meter example">
      <rect x="22" y="14" width="76" height="92" rx="10" stroke="var(--green)" strokeWidth="3" />
      <rect x="34" y="28" width="52" height="30" rx="5" fill="none" stroke="var(--cyan, #1ee7ff)" strokeWidth="2.5" />
      <text x="60" y="49" textAnchor="middle" fontSize="14" fontWeight="800" fill="var(--cyan, #1ee7ff)" fontFamily="monospace">8842</text>
      <circle cx="44" cy="76" r="6" stroke="var(--green)" strokeWidth="2.5" />
      <circle cx="62" cy="76" r="6" stroke="var(--green)" strokeWidth="2.5" />
      <circle cx="80" cy="76" r="6" stroke="var(--green)" strokeWidth="2.5" />
      <rect x="40" y="92" width="40" height="6" rx="3" fill="var(--green)" />
    </svg>
  );
}

/** A house with a roof outline being traced — example for the roof step. */
export function RoofOutlineExample() {
  return (
    <svg className={s.art} viewBox="0 0 130 110" fill="none" aria-label="Roof outline example">
      <path d="M18 60 L65 24 L112 60 L112 96 L18 96 Z" stroke="#9fb0d8" strokeWidth="2" opacity="0.55" />
      <path
        d="M18 60 L65 24 L112 60"
        stroke="var(--pink)"
        strokeWidth="4"
        strokeLinecap="round"
        strokeLinejoin="round"
        strokeDasharray="6 7"
      />
      <circle cx="112" cy="60" r="5.5" fill="var(--pink)" />
      <path d="M40 96 V70 H56 V96" stroke="#9fb0d8" strokeWidth="2" opacity="0.5" />
    </svg>
  );
}

/** A power pole — example for section 3. */
export function PoleExample() {
  return (
    <svg className={s.art} viewBox="0 0 120 120" fill="none" aria-label="Power pole example">
      <path d="M60 16 V104" stroke="var(--green)" strokeWidth="4" strokeLinecap="round" />
      <path d="M30 34 H90 M34 48 H86" stroke="var(--green)" strokeWidth="3" strokeLinecap="round" />
      <path d="M34 34 Q60 60 86 34" stroke="var(--cyan, #1ee7ff)" strokeWidth="2" opacity="0.8" />
      <path d="M34 48 Q60 74 86 48" stroke="var(--cyan, #1ee7ff)" strokeWidth="2" opacity="0.8" />
      <circle cx="34" cy="34" r="3.5" fill="var(--green)" />
      <circle cx="86" cy="34" r="3.5" fill="var(--green)" />
    </svg>
  );
}
