import { useRef, useState } from "react";
import s from "./capture.module.css";

interface RoofOutlineProps {
  /** Called with the number of points drawn when the user lifts their finger. */
  onChange?: (points: number) => void;
}

/** A transparent finger-draw canvas for tracing the roof edge (simulated). */
export function RoofOutline({ onChange }: RoofOutlineProps) {
  const ref = useRef<HTMLCanvasElement>(null);
  const drawing = useRef(false);
  const points = useRef(0);
  const [, force] = useState(0);

  function ctx() {
    const c = ref.current!;
    if (c.width !== c.clientWidth * 2) {
      c.width = c.clientWidth * 2;
      c.height = c.clientHeight * 2;
    }
    const g = c.getContext("2d")!;
    g.scale(1, 1);
    return g;
  }

  function pos(e: React.PointerEvent) {
    const r = ref.current!.getBoundingClientRect();
    return { x: (e.clientX - r.left) * 2, y: (e.clientY - r.top) * 2 };
  }

  function start(e: React.PointerEvent) {
    drawing.current = true;
    const g = ctx();
    const p = pos(e);
    g.beginPath();
    g.moveTo(p.x, p.y);
    g.strokeStyle = "#ff4fe0";
    g.lineWidth = 7;
    g.lineCap = "round";
    g.lineJoin = "round";
    g.shadowColor = "#ff4fe0";
    g.shadowBlur = 18;
  }
  function move(e: React.PointerEvent) {
    if (!drawing.current) return;
    const g = ctx();
    const p = pos(e);
    g.lineTo(p.x, p.y);
    g.stroke();
    points.current += 1;
  }
  function end() {
    drawing.current = false;
    onChange?.(points.current);
    force((n) => n + 1);
  }
  function clear() {
    const c = ref.current!;
    c.getContext("2d")!.clearRect(0, 0, c.width, c.height);
    points.current = 0;
    onChange?.(0);
    force((n) => n + 1);
  }

  return (
    <div className={s.outlineWrap}>
      <canvas
        ref={ref}
        className={s.outlineCanvas}
        onPointerDown={start}
        onPointerMove={move}
        onPointerUp={end}
        onPointerLeave={end}
      />
      {points.current === 0 && <span className={s.outlineHint}>Draw around the roof edge</span>}
      {points.current > 0 && (
        <button className={s.outlineClear} onClick={clear} type="button">
          Clear
        </button>
      )}
    </div>
  );
}
